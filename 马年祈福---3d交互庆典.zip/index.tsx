import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import gsap from 'gsap';

// --- Constants & Config ---
const GameState = {
    LOADING: 'LOADING',
    OPENING: 'OPENING',
    READY: 'READY',
    EXPLODING: 'EXPLODING',
    SHOWING_SLIP: 'SHOWING_SLIP'
};

const COLORS = {
    DEEP_SEA_BLUE: '#001a33',
    CINNABAR_RED: '#8b0000',
    GOLD: '#FFF59D',
    DARK_GOLD: '#D4AF37',
    PARCHMENT: '#f4e4bc'
};

const FORTUNE_SLIPS = [
    "万事胜意 岁岁平安",
    "一马当先 步步高升",
    "龙马精神 福满门庭",
    "前程似锦 马到功成",
    "身体健康 阖家欢乐",
    "瑞气盈门 吉星高照"
];

// --- Texture Generation Services ---
const createFortuneSlipTexture = (text: string): THREE.CanvasTexture => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');
    if (!ctx) return new THREE.CanvasTexture(canvas);

    ctx.fillStyle = COLORS.PARCHMENT;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    for (let i = 0; i < 15000; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        ctx.fillStyle = `rgba(80, 50, 20, ${Math.random() * 0.06})`;
        ctx.fillRect(x, y, Math.random() * 2, Math.random() * 2);
    }

    ctx.strokeStyle = '#3a2e1e';
    ctx.lineWidth = 5;
    const drawHandDrawnRect = (x: number, y: number, w: number, h: number) => {
        ctx.beginPath();
        let curX = x, curY = y;
        ctx.moveTo(curX, curY);
        const steps = 150; 
        const drift = 1.2;
        for (let i = 1; i <= steps; i++) { curX = x + (w / steps) * i; curY += (Math.random() - 0.5) * drift; ctx.lineTo(curX, curY); }
        for (let i = 1; i <= steps; i++) { curY = y + (h / steps) * i; curX += (Math.random() - 0.5) * drift; ctx.lineTo(curX, curY); }
        for (let i = 1; i <= steps; i++) { curX = x + w - (w / steps) * i; curY += (Math.random() - 0.5) * drift; ctx.lineTo(curX, curY); }
        for (let i = 1; i <= steps; i++) { curY = y + h - (h / steps) * i; curX += (Math.random() - 0.5) * drift; ctx.lineTo(curX, curY); }
        ctx.closePath();
        ctx.stroke();
    };

    drawHandDrawnRect(40, 40, canvas.width - 80, canvas.height - 80);
    ctx.lineWidth = 2;
    drawHandDrawnRect(55, 55, canvas.width - 110, canvas.height - 110);

    ctx.fillStyle = '#111111';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const fontSize = 72;
    ctx.font = `bold ${fontSize}px "Ma Shan Zheng", "Noto Serif SC", serif`;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
    ctx.shadowBlur = 3;
    
    const chars = text.split('').filter(c => c.trim() !== '' && c !== '，' && c !== ' ');
    const totalH = chars.length * fontSize * 1.35;
    const startY = (canvas.height - totalH) / 2 + fontSize / 2;
    
    chars.forEach((char, index) => {
        ctx.save();
        const offsetX = (Math.random() - 0.5) * 14; 
        const offsetY = (Math.random() - 0.5) * 8;
        const rotate = (Math.random() - 0.5) * 0.15;
        const scale = 0.95 + Math.random() * 0.1;
        ctx.translate(canvas.width / 2 + offsetX, startY + index * fontSize * 1.35 + offsetY);
        ctx.rotate(rotate);
        ctx.scale(scale, scale);
        ctx.fillText(char, 0, 0);
        ctx.restore();
    });

    ctx.shadowBlur = 0;
    ctx.fillStyle = 'rgba(170, 0, 0, 0.9)';
    const sealX = canvas.width - 150, sealY = canvas.height - 170;
    ctx.fillRect(sealX, sealY, 95, 95);
    ctx.strokeStyle = COLORS.PARCHMENT;
    ctx.lineWidth = 3;
    ctx.strokeRect(sealX + 6, sealY + 6, 83, 83);
    ctx.fillStyle = COLORS.PARCHMENT;
    ctx.font = '24px "Ma Shan Zheng"';
    ctx.fillText('丙午', sealX + 47, sealY + 35);
    ctx.fillText('马年', sealX + 47, sealY + 65);

    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;
    return texture;
};

const createGreetingTexture = (text: string, fontFamily: string): THREE.CanvasTexture => {
    const canvas = document.createElement('canvas');
    canvas.width = 1024; canvas.height = 320;
    const ctx = canvas.getContext('2d');
    if (!ctx) return new THREE.CanvasTexture(canvas);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const boxY = 40, boxH = 150;
    const gradient = ctx.createLinearGradient(0, 0, 550, 0);
    gradient.addColorStop(0, 'rgba(255, 255, 255, 0.15)');
    gradient.addColorStop(0.5, 'rgba(255, 255, 255, 0.05)');
    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(40, boxY, 550, boxH);
    ctx.fillStyle = '#C0392B';
    ctx.fillRect(40, boxY, 5, boxH);
    ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.shadowBlur = 10;
    ctx.fillStyle = COLORS.GOLD;
    ctx.font = 'italic bold 24px sans-serif';
    ctx.fillText('to', 65, boxY + 35);
    ctx.fillStyle = '#ffffff';
    const mainFont = fontFamily === 'serif' ? '"Noto Serif SC", serif' : 'sans-serif';
    ctx.font = `bold 56px ${mainFont}`;
    ctx.fillText(text || '各位追梦人', 65, boxY + 95);
    ctx.shadowBlur = 0; ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(65, boxY + 120); ctx.lineTo(380, boxY + 120); ctx.stroke();
    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true; return texture;
};

const createYearTexture = (): THREE.CanvasTexture => {
    const canvas = document.createElement('canvas');
    canvas.width = 1024; canvas.height = 320;
    const ctx = canvas.getContext('2d');
    if (!ctx) return new THREE.CanvasTexture(canvas);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.shadowColor = 'rgba(0,0,0,0.8)'; ctx.shadowBlur = 20;
    ctx.font = 'bold 120px "Noto Serif SC", serif'; ctx.fillStyle = COLORS.GOLD;
    ctx.fillText('2026', 70, 140);
    ctx.shadowBlur = 8; ctx.font = 'italic 40px sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.letterSpacing = "8px"; ctx.fillText('HAPPY NEW YEAR', 75, 210);
    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true; return texture;
};

// --- UI Components ---
const LoadingScreen = ({ progress }: { progress: number }) => (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#001a33]">
        <div className="mb-8 relative">
            <div className="w-24 h-24 border-4 border-white/10 border-t-[#FFF59D] rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center text-sm font-bold text-[#FFF59D]">{Math.floor(progress)}%</div>
        </div>
        <h1 className="text-2xl tracking-[0.5em] uppercase font-serif animate-pulse text-white">马年祈福・正在载入灵韵</h1>
        <p className="mt-4 text-white/40 text-xs italic tracking-widest uppercase">Initializing Fortune Realm</p>
    </div>
);

const Toolbar = ({ settings, setSettings, gameState, onExplode, onReset }: any) => (
    <div className="h-full bg-white/5 backdrop-blur-3xl rounded-[2.5rem] border border-white/10 p-8 flex flex-col gap-8 pointer-events-auto shadow-2xl overflow-y-auto custom-scrollbar transition-all duration-500">
        <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-red-600 rounded-2xl flex items-center justify-center animate-bounce shadow-lg shadow-red-900/40"><span className="text-2xl">🧧</span></div>
            <div>
                <h2 className="text-xl font-bold tracking-tight text-white">祈福工坊</h2>
                <p className="text-[9px] text-white/30 uppercase tracking-[0.2em] font-bold">Atmosphere Control</p>
            </div>
        </div>
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="space-y-6">
            <section className="space-y-3">
                <label className="text-[10px] uppercase tracking-widest text-white/40 font-black">接收祝福者</label>
                <input type="text" maxLength={10} value={settings.greetingName} onChange={(e) => setSettings((s: any) => ({...s, greetingName: e.target.value}))} className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-white/20 text-white placeholder:text-white/20" />
            </section>
            <section className="space-y-3">
                <label className="text-[10px] uppercase tracking-widest text-white/40 font-black">字体风格</label>
                <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => setSettings((s: any) => ({...s, fontFamily: 'serif'}))} className={`py-3 rounded-xl text-xs transition-all border ${settings.fontFamily === 'serif' ? 'bg-white text-black border-white shadow-lg font-bold' : 'bg-white/5 border-white/10 text-white/50'}`}>衬线体</button>
                    <button onClick={() => setSettings((s: any) => ({...s, fontFamily: 'sans'}))} className={`py-3 rounded-xl text-xs transition-all border ${settings.fontFamily === 'sans' ? 'bg-white text-black border-white shadow-lg font-bold' : 'bg-white/5 border-white/10 text-white/50'}`}>无衬线体</button>
                </div>
            </section>
            <section className="space-y-6">
                <div className="space-y-3">
                    <div className="flex justify-between items-center"><label className="text-[10px] uppercase tracking-widest text-white/40 font-black">灵马速度</label><span className="text-[9px] font-mono text-white/30">{settings.horseSpeed.toFixed(1)}x</span></div>
                    <input type="range" min="0.1" max="3" step="0.1" value={settings.horseSpeed} onChange={(e) => setSettings((s: any) => ({...s, horseSpeed: parseFloat(e.target.value)}))} className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-white" />
                </div>
                <div className="space-y-3">
                    <div className="flex justify-between items-center"><label className="text-[10px] uppercase tracking-widest text-white/40 font-black">瑞雪速度</label><span className="text-[9px] font-mono text-white/30">{settings.snowSpeed.toFixed(1)}x</span></div>
                    <input type="range" min="0" max="5" step="0.1" value={settings.snowSpeed} onChange={(e) => setSettings((s: any) => ({...s, snowSpeed: parseFloat(e.target.value)}))} className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-white" />
                </div>
            </section>
        </div>
        <div className="mt-auto pt-6">
            {gameState === GameState.READY ? (
                <button onClick={onExplode} className="w-full bg-gradient-to-r from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 text-white font-bold py-5 rounded-2xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-3 group">
                    <span className="group-hover:animate-pulse">✨</span> 开启灵签 <span className="group-hover:animate-pulse">✨</span>
                </button>
            ) : gameState === GameState.SHOWING_SLIP ? (
                <button onClick={onReset} className="w-full bg-white/10 hover:bg-white/20 text-white border border-white/20 py-5 rounded-2xl transition-all font-bold">重置场景</button>
            ) : <div className="text-center text-white/20 italic text-xs py-4 tracking-widest animate-pulse">境域同步中...</div>}
        </div>
    </div>
);

// --- 3D Scene Controller ---
const SceneManager = ({ settings, gameState, setGameState, setLoadingProgress }: any) => {
    const mountRef = useRef<HTMLDivElement>(null);
    const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
    const sceneRef = useRef<THREE.Scene | null>(null);
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
    const mixerRef = useRef<THREE.AnimationMixer | null>(null);
    const clockRef = useRef(new THREE.Clock());
    const particlesRef = useRef<THREE.Points | null>(null);
    const snowRef = useRef<THREE.Points | null>(null);
    const fortuneSlipRef = useRef<THREE.Mesh | null>(null);
    const uiGroupRef = useRef<THREE.Group | null>(null);
    const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
    const greetingMeshRef = useRef<THREE.Mesh | null>(null);
    const yearMeshRef = useRef<THREE.Mesh | null>(null);
    const PARTICLE_COUNT = 22000;

    // 记录灵签在不同状态下的目标位置和缩放 (Stored reactive targets)
    // 签文 position slightly down (Moved down slightly from 0.15 to -0.25)
    const slipTargets = useRef({ y: -0.25, z: 2.5, scale: 1.0 });

    useEffect(() => {
        if (!mountRef.current) return;
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(COLORS.DEEP_SEA_BLUE);
        scene.fog = new THREE.FogExp2(COLORS.DEEP_SEA_BLUE, 0.012);
        sceneRef.current = scene;
        const camera = new THREE.PerspectiveCamera(45, mountRef.current.clientWidth / mountRef.current.clientHeight, 0.1, 1000);
        camera.position.set(0, 0, 18);
        cameraRef.current = camera;
        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
        renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        mountRef.current.appendChild(renderer.domElement);
        rendererRef.current = renderer;
        
        const ambientLight = new THREE.AmbientLight(0xffffff, 1.8);
        scene.add(ambientLight);
        ambientLightRef.current = ambientLight;

        const uiGroup = new THREE.Group(); scene.add(uiGroup); uiGroupRef.current = uiGroup;
        const greetingMesh = new THREE.Mesh(new THREE.PlaneGeometry(8, 2.5), new THREE.MeshBasicMaterial({ transparent: true, depthTest: false, depthWrite: false }));
        uiGroup.add(greetingMesh); greetingMeshRef.current = greetingMesh;
        const yearMesh = new THREE.Mesh(new THREE.PlaneGeometry(8, 2.5), new THREE.MeshBasicMaterial({ map: createYearTexture(), transparent: true, depthTest: false, depthWrite: false }));
        uiGroup.add(yearMesh); yearMeshRef.current = yearMesh;

        const updateUIPos = () => {
            const cam = cameraRef.current; if (!cam) return;
            const distUI = 6.0;
            const hUI = 2 * Math.tan(THREE.MathUtils.degToRad(cam.fov) / 2) * distUI;
            const wUI = hUI * cam.aspect;
            const scaleUI = Math.min(wUI * 0.06, 0.8);
            greetingMesh.position.set(-wUI / 2 + 3.8 * scaleUI, hUI / 2 - 1.4 * scaleUI, 0); greetingMesh.scale.setScalar(scaleUI);
            yearMesh.position.set(-wUI / 2 + 3.8 * scaleUI, -hUI / 2 + 1.4 * scaleUI, 0); yearMesh.scale.setScalar(scaleUI);

            if (fortuneSlipRef.current) {
                const slipPlaneZ = 2.5;
                const distToSlip = cam.position.z - slipPlaneZ;
                const hAtSlip = 2 * Math.tan(THREE.MathUtils.degToRad(cam.fov) / 2) * distToSlip;
                const wAtSlip = hAtSlip * cam.aspect;
                
                const sH = (hAtSlip * 0.78) / 7.2;
                const sW = (wAtSlip * 0.88) / 3.6;
                const slipScale = Math.min(sH, sW, 1.2);
                slipTargets.current.scale = slipScale;
                slipTargets.current.y = -0.25; // Adjusted down
                slipTargets.current.z = slipPlaneZ;

                if (gameState === GameState.SHOWING_SLIP) {
                    fortuneSlipRef.current.scale.setScalar(slipScale);
                    fortuneSlipRef.current.position.y = slipTargets.current.y;
                    fortuneSlipRef.current.position.z = slipTargets.current.z;
                } else {
                    fortuneSlipRef.current.scale.setScalar(slipScale);
                    fortuneSlipRef.current.position.y = -hAtSlip - 5; 
                }
            }
        };

        const loader = new GLTFLoader();
        loader.load('https://cdn.jsdelivr.net/gh/mrdoob/three.js@r173/examples/models/gltf/Horse.glb', (gltf) => {
            const horse = gltf.scene.children[0] as THREE.Mesh;
            const geometry = (horse.geometry as THREE.BufferGeometry).clone();
            const mixer = new THREE.AnimationMixer(gltf.scene); mixer.clipAction(gltf.animations[0]).play(); mixerRef.current = mixer;
            const barycentrics = new Float32Array(PARTICLE_COUNT * 3);
            const faceIndices = new Float32Array(PARTICLE_COUNT * 3);
            const velocities = new Float32Array(PARTICLE_COUNT * 3);
            const attrPos = geometry.attributes.position;
            const attrIndex = geometry.index;
            for (let i = 0; i < PARTICLE_COUNT; i++) {
                let a, b, c;
                if (attrIndex) {
                    const faceIdx = Math.floor(Math.random() * (attrIndex.count / 3)) * 3;
                    a = attrIndex.getX(faceIdx); b = attrIndex.getX(faceIdx + 1); c = attrIndex.getX(faceIdx + 2);
                } else { const faceIdx = Math.floor(Math.random() * (attrPos.count / 3)) * 3; a = faceIdx; b = faceIdx + 1; c = faceIdx + 2; }
                const r1 = Math.random(), r2 = Math.random(), sqrtR1 = Math.sqrt(r1);
                barycentrics[i*3] = 1-sqrtR1; barycentrics[i*3+1] = r2*sqrtR1; barycentrics[i*3+2] = 1-barycentrics[i*3]-barycentrics[i*3+1];
                faceIndices[i*3] = a; faceIndices[i*3+1] = b; faceIndices[i*3+2] = c;
                const theta = Math.random()*Math.PI*2, phi = Math.acos(2*Math.random()-1), spd = 15 + Math.random()*25;
                velocities[i*3] = Math.sin(phi)*Math.cos(theta)*spd; velocities[i*3+1] = Math.sin(phi)*Math.sin(theta)*spd; velocities[i*3+2] = Math.cos(phi)*spd;
            }
            const particleGeom = new THREE.BufferGeometry();
            particleGeom.setAttribute('position', new THREE.BufferAttribute(new Float32Array(PARTICLE_COUNT*3), 3));
            particleGeom.setAttribute('barycentric', new THREE.BufferAttribute(barycentrics, 3));
            particleGeom.setAttribute('faceIndices', new THREE.BufferAttribute(faceIndices, 3));
            particleGeom.setAttribute('velocity', new THREE.BufferAttribute(velocities, 3));
            const mat = new THREE.PointsMaterial({ size: 0.05, color: COLORS.GOLD, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
            const points = new THREE.Points(particleGeom, mat); points.scale.setScalar(0.016); points.rotation.y = -Math.PI / 2; points.position.set(0, -2, 0);
            scene.add(points); particlesRef.current = points; points.userData = { horse, explosionProgress: 0, explosionPositions: new Float32Array(PARTICLE_COUNT*3) };
            const snowArr = new Float32Array(6000 * 3); for (let i = 0; i < 18000; i++) snowArr[i] = (Math.random() - 0.5) * 80;
            const snowGeom = new THREE.BufferGeometry(); snowGeom.setAttribute('position', new THREE.BufferAttribute(snowArr, 3));
            const snowPoints = new THREE.Points(snowGeom, new THREE.PointsMaterial({ color: 0xffffff, size: 0.12, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending }));
            scene.add(snowPoints); snowRef.current = snowPoints;
            const slip = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 7.2), new THREE.MeshBasicMaterial({ transparent: true, side: THREE.DoubleSide }));
            slip.position.set(0, -20, 2.5); slip.rotation.y = Math.PI; scene.add(slip); fortuneSlipRef.current = slip;
            setGameState(GameState.OPENING);
            const tl = gsap.timeline({ onComplete: () => { setGameState(GameState.READY); updateUIPos(); } });
            tl.to(scene.background, { r: new THREE.Color(COLORS.CINNABAR_RED).r, g: new THREE.Color(COLORS.CINNABAR_RED).g, b: new THREE.Color(COLORS.CINNABAR_RED).b, duration: 4.5, ease: "sine.inOut" }, 0);
            tl.to(scene.fog.color, { r: new THREE.Color(COLORS.CINNABAR_RED).r, g: new THREE.Color(COLORS.CINNABAR_RED).g, b: new THREE.Color(COLORS.CINNABAR_RED).b, duration: 4.5, ease: "sine.inOut" }, 0);
            tl.to(camera.position, { z: 6, duration: 4, ease: "expo.out", onUpdate: updateUIPos }, 0.5);
        }, (xhr) => { if (xhr.total > 0) setLoadingProgress((xhr.loaded / xhr.total) * 100); });

        const handleResize = () => {
            if (!mountRef.current || !cameraRef.current || !rendererRef.current) return;
            cameraRef.current.aspect = mountRef.current.clientWidth / mountRef.current.clientHeight; cameraRef.current.updateProjectionMatrix(); 
            rendererRef.current.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
            updateUIPos();
        };
        window.addEventListener('resize', handleResize);
        const animate = () => {
            requestAnimationFrame(animate); const dt = clockRef.current.getDelta(), time = clockRef.current.getElapsedTime();
            if (mixerRef.current && gameState !== GameState.EXPLODING && gameState !== GameState.SHOWING_SLIP) mixerRef.current.update(dt * settings.horseSpeed);
            if (particlesRef.current) {
                const p = particlesRef.current; const { horse, explosionPositions } = p.userData; const posAttr = p.geometry.attributes.position as THREE.BufferAttribute;
                const isEx = (gameState === GameState.EXPLODING || gameState === GameState.SHOWING_SLIP);
                if (isEx) p.userData.explosionProgress += dt;
                for (let i = 0; i < PARTICLE_COUNT; i++) {
                    if (!isEx) {
                        const u = p.geometry.attributes.barycentric.getX(i), v = p.geometry.attributes.barycentric.getY(i), w = p.geometry.attributes.barycentric.getZ(i);
                        const i1 = p.geometry.attributes.faceIndices.getX(i), i2 = p.geometry.attributes.faceIndices.getY(i), i3 = p.geometry.attributes.faceIndices.getZ(i);
                        const getV = (idx: number, target: THREE.Vector3) => {
                            target.fromBufferAttribute(horse.geometry.attributes.position as THREE.BufferAttribute, idx);
                            if (horse.morphTargetInfluences) {
                                for (let m = 0; m < horse.morphTargetInfluences.length; m++) if (horse.morphTargetInfluences[m] > 0) {
                                    const mp = horse.geometry.morphAttributes.position[m] as THREE.BufferAttribute;
                                    target.x += mp.getX(idx) * horse.morphTargetInfluences[m]; target.y += mp.getY(idx) * horse.morphTargetInfluences[m]; target.z += mp.getZ(idx) * horse.morphTargetInfluences[m];
                                }
                            }
                        };
                        const v1 = new THREE.Vector3(), v2 = new THREE.Vector3(), v3 = new THREE.Vector3(); getV(i1, v1); getV(i2, v2); getV(i3, v3);
                        posAttr.setXYZ(i, v1.x * u + v2.x * v + v3.x * w, v1.y * u + v2.y * v + v3.y * w, v1.z * u + v2.z * v + v3.z * w);
                        explosionPositions[i*3] = posAttr.getX(i); explosionPositions[i*3+1] = posAttr.getY(i); explosionPositions[i*3+2] = posAttr.getZ(i);
                    } else {
                        const t = p.userData.explosionProgress, drag = Math.exp(-2.2 * t), velAttr = p.geometry.attributes.velocity as THREE.BufferAttribute;
                        posAttr.setXYZ(i, 
                            explosionPositions[i*3] + velAttr.getX(i) * t * drag + Math.sin(time*12+i)*0.6*t, 
                            explosionPositions[i*3+1] + velAttr.getY(i) * t * drag - 0.6*t*t + Math.cos(time*12+i)*0.6*t, 
                            explosionPositions[i*3+2] + velAttr.getZ(i) * t * drag
                        );
                    }
                }
                const mat = p.material as THREE.PointsMaterial; const t = p.userData.explosionProgress;
                if (isEx) {
                    const fadeT = Math.max(0, (t - 0.1) / 1.2); mat.opacity = Math.max(0, 1.0 * (1.0 - fadeT * 1.5));
                    let szMult = 1; if (t < 0.1) szMult = 1 + (t / 0.1) * 8; else szMult = Math.max(0, 9 - ((t - 0.1) / 1.1) * 9);
                    mat.size = 0.05 * szMult; mat.color.setHSL(0.12, 0.9, 0.5 + Math.max(0, 1.0 - t * 4) * 0.5); 
                } else { mat.opacity = 0.9; mat.size = 0.05; mat.color.set(COLORS.GOLD); }
                posAttr.needsUpdate = true;
            }
            if (snowRef.current) {
                const pos = snowRef.current.geometry.attributes.position as THREE.BufferAttribute;
                for (let i = 0; i < pos.count; i++) { let y = pos.getY(i) - 0.12 * settings.snowSpeed; if (y < -40) y = 40; pos.setY(i, y); }
                pos.needsUpdate = true;
            }
            if (cameraRef.current) {
                cameraRef.current.lookAt(0, -0.6, 0);
                if (uiGroupRef.current) { uiGroupRef.current.position.copy(cameraRef.current.position); uiGroupRef.current.quaternion.copy(cameraRef.current.quaternion); uiGroupRef.current.translateZ(-6.0); }
            }
            rendererRef.current?.render(scene, cameraRef.current!);
        };
        animate(); return () => { window.removeEventListener('resize', handleResize); renderer.dispose(); };
    }, []);

    useEffect(() => {
        if (greetingMeshRef.current) { const mat = greetingMeshRef.current.material as THREE.MeshBasicMaterial; mat.map?.dispose(); mat.map = createGreetingTexture(settings.greetingName, settings.fontFamily); mat.needsUpdate = true; }
    }, [settings.greetingName, settings.fontFamily]);

    useEffect(() => {
        if (gameState === GameState.EXPLODING) {
            if (particlesRef.current) particlesRef.current.userData.explosionProgress = 0;
            if (ambientLightRef.current) {
                gsap.to(ambientLightRef.current, { intensity: 15, duration: 0.1, yoyo: true, repeat: 1, ease: "power2.out" });
            }
            if (cameraRef.current) {
                const originalZ = cameraRef.current.position.z; const shakeTl = gsap.timeline();
                for(let i=0; i<15; i++) { shakeTl.to(cameraRef.current.position, { x: (Math.random()-0.5)*1.2, y: (Math.random()-0.5)*1.2, z: originalZ + (Math.random()-0.5)*0.6, duration: 0.03 }); }
                shakeTl.to(cameraRef.current.position, { x: 0, y: 0, z: originalZ, duration: 0.4, ease: "elastic.out(1, 0.3)" });
            }
            setTimeout(() => setGameState(GameState.SHOWING_SLIP), 1100);
        }
        if (gameState === GameState.SHOWING_SLIP && fortuneSlipRef.current) {
            const mat = fortuneSlipRef.current.material as THREE.MeshBasicMaterial;
            mat.map?.dispose(); mat.map = createFortuneSlipTexture(FORTUNE_SLIPS[Math.floor(Math.random() * FORTUNE_SLIPS.length)]); mat.needsUpdate = true;
            gsap.to(fortuneSlipRef.current.position, { y: slipTargets.current.y, z: slipTargets.current.z, duration: 1.8, ease: "back.out(1.5)" });
            gsap.to(fortuneSlipRef.current.rotation, { y: Math.PI * 2, duration: 2.2, ease: "power3.out" });
        }
        if (gameState === GameState.READY && fortuneSlipRef.current) {
            const cam = cameraRef.current;
            const hAtSlip = cam ? 2 * Math.tan(THREE.MathUtils.degToRad(cam.fov) / 2) * (cam.position.z - 2.5) : 10;
            gsap.to(fortuneSlipRef.current.position, { y: -hAtSlip - 5, duration: 1, ease: "power2.in" });
        }
    }, [gameState]);

    return <div ref={mountRef} className="w-full h-full" />;
};

const App = () => {
    const [settings, setSettings] = useState({ fontFamily: 'serif', horseSpeed: 1.0, snowSpeed: 1.3, showUI: true, greetingName: '各位追梦人' });
    const [gameState, setGameState] = useState(GameState.LOADING);
    const [loadingProgress, setLoadingProgress] = useState(0);

    return (
        <div className="relative w-full h-screen overflow-hidden text-white font-sans transition-colors duration-[4500ms]" style={{ backgroundColor: (gameState === GameState.LOADING || gameState === GameState.OPENING) ? COLORS.DEEP_SEA_BLUE : COLORS.CINNABAR_RED }}>
            <div className={`absolute inset-0 h-full transition-all duration-1000 ${settings.showUI ? 'md:w-[75%]' : 'w-full'}`}>
                <SceneManager settings={settings} gameState={gameState} setGameState={setGameState} setLoadingProgress={setLoadingProgress} />
            </div>
            {settings.showUI && (
                <div className="absolute inset-y-0 right-0 w-full md:w-[25%] p-5 z-20 pointer-events-none">
                    <Toolbar settings={settings} setSettings={setSettings} gameState={gameState} onExplode={() => setGameState(GameState.EXPLODING)} onReset={() => setGameState(GameState.READY)} />
                </div>
            )}
            <button onClick={() => setSettings(s => ({...s, showUI: !s.showUI}))} className="absolute bottom-8 left-8 z-30 p-4 bg-white/5 backdrop-blur-3xl rounded-full border border-white/20 hover:bg-white/15 transition-all pointer-events-auto shadow-2xl">
                {settings.showUI ? <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg> : <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="3"/><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/></svg>}
            </button>
            {gameState === GameState.LOADING && <LoadingScreen progress={loadingProgress} />}
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
